
import { useEffect, useState } from 'react'
import {
  Activity, AlertTriangle, CarFront, CheckCircle2, CloudUpload,
  FileVideo, LayoutDashboard, Radio, RefreshCw, ShieldCheck, Video,
} from 'lucide-react'
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'

const sections = ['Overview', 'Video Analysis', 'Violation Review', 'Live Monitoring', 'Analytics']

export default function App() {
  const [page, setPage] = useState('Overview')
  const [apiOnline, setApiOnline] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [jobId, setJobId] = useState('')
  const [job, setJob] = useState<Record<string, any> | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [cases, setCases] = useState<Record<string, any>[]>([])
  const [reviewMessage, setReviewMessage] = useState('')

  async function checkApi() {
    try {
      const r = await fetch('/docs')
      setApiOnline(r.ok)
    } catch {
      setApiOnline(false)
    }
  }

  useEffect(() => { void checkApi() }, [])

  useEffect(() => {
    if (!jobId) return
    let cancelled = false
    let timer: ReturnType<typeof setTimeout>
    async function poll() {
      try {
        const r = await fetch(`/api/v1/inference/jobs/${encodeURIComponent(jobId)}`)
        const data = await r.json()
        if (!r.ok) throw new Error(data.detail || `Job status: ${r.status}`)
        if (cancelled) return
        setJob(data)
        const s = String(data.status || data.state || '').toLowerCase()
        if (!['completed', 'complete', 'failed', 'error', 'cancelled'].includes(s)) {
          timer = setTimeout(poll, 2500)
        }
      } catch {
        if (!cancelled) timer = setTimeout(poll, 5000)
      }
    }
    void poll()
    return () => { cancelled = true; clearTimeout(timer) }
  }, [jobId])

  async function submitVideo() {
    if (!file) {
      setError('Choose a video file first.')
      return
    }
    setBusy(true)
    setError('')
    try {
      const form = new FormData()
      form.append('file', file)
      const r = await fetch('/api/v1/inference/video', { method: 'POST', body: form })
      const data = await r.json()
      if (!r.ok) throw new Error(data.detail || `Upload failed: ${r.status}`)
      const id = data.job_id || data.id || data.jobId
      if (!id) throw new Error('No job ID returned. Check the endpoint schema in FastAPI /docs.')
      setJobId(String(id))
      setJob(data)
      setPage('Video Analysis')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Video upload failed.')
    } finally {
      setBusy(false)
    }
  }

  async function loadCases() {
    if (!jobId) {
      setReviewMessage('Upload a video and submit an inference job first.')
      return
    }
    setReviewMessage('Loading evidence…')
    try {
      const r = await fetch(`/api/v1/inference/jobs/${encodeURIComponent(jobId)}/review-cases`)
      const data = await r.json()
      if (!r.ok) throw new Error(data.detail || `Review API: ${r.status}`)
      const rows = Array.isArray(data) ? data : data.review_cases || data.cases || data.items || []
      setCases(rows)
      setReviewMessage(`${rows.length} review candidates loaded. Human verification is required.`)
    } catch (e) {
      setReviewMessage(e instanceof Error ? e.message : 'Could not load review cases.')
    }
  }

  const status = String(job?.status || job?.state || 'Idle').replaceAll('_', ' ')
  const chart = [
    { time: '08:00', count: 0 }, { time: '09:00', count: 0 },
    { time: '10:00', count: 0 }, { time: '11:00', count: 0 },
    { time: '12:00', count: 0 }, { time: '13:00', count: 0 },
  ]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-icon"><ShieldCheck /></div><div><strong>Traffic<span>AI</span></strong><small>INTELLIGENCE PLATFORM</small></div></div>
        <div className="eyebrow">WORKSPACE</div>
        <nav>{sections.map((s, i) => {
          const Icon = [LayoutDashboard, Video, ShieldCheck, Radio, Activity][i]
          return <button key={s} onClick={() => setPage(s)} className={page === s ? 'nav-item active' : 'nav-item'}><Icon size={18}/>{s}</button>
        })}</nav>
        <div className="sidebar-bottom"><div className="live-dot"/><div><strong>{apiOnline ? 'Backend reachable' : 'Backend not confirmed'}</strong><small>{apiOnline ? 'API response received' : 'Check FastAPI on port 8000'}</small></div></div>
      </aside>

      <main className="main">
        <header className="topbar"><div><small>TrafficAI / {page}</small><h1>{page === 'Overview' ? 'Control Center' : page}</h1></div><button className="icon-button" onClick={() => void checkApi()} title="Check backend"><RefreshCw size={17}/></button></header>
        <div className="content">
          {page === 'Overview' && <>
            <div className="hero"><div><div className="eyebrow cyan">TRAFFIC INTELLIGENCE SYSTEM</div><h2>See the road.<br/><span>Understand the risk.</span></h2><p>Video inference, violation evidence and adaptive traffic monitoring in one workspace.</p><button className="primary" onClick={() => setPage('Video Analysis')}><CloudUpload size={17}/> Analyze a video</button></div><div className="hero-art"><div className="road"><div className="road-line"/></div><div className="scan-box"><CarFront size={44}/><span>VEHICLE TRACKING</span><i/></div><div className="art-tag">VISION SYSTEM <b>● ACTIVE UI</b></div></div></div>
            <div className="metrics">
              <Metric icon={Activity} label="Backend status" value={apiOnline ? 'Reachable' : 'Unconfirmed'} note="Live connection check" />
              <Metric icon={FileVideo} label="Current job" value={jobId ? jobId.slice(0, 8) : 'No job yet'} note={job ? status : 'Upload a video to begin'} />
              <Metric icon={AlertTriangle} label="Review candidates" value={String(cases.length)} note="Loaded from review API" />
              <Metric icon={CheckCircle2} label="Inference status" value={status} note="Latest job response" />
            </div>
            <div className="two-column">
              <section className="panel"><div className="panel-heading"><div><h3>Detection activity</h3><p>Waiting for real event telemetry</p></div><span className="tag">NO LIVE DATA YET</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chart}><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#36d5d0" stopOpacity={.3}/><stop offset="100%" stopColor="#36d5d0" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#243246" strokeDasharray="3 4" vertical={false}/><XAxis dataKey="time" tick={{fill:'#8493a9',fontSize:11}} axisLine={false} tickLine={false}/><YAxis tick={{fill:'#8493a9',fontSize:11}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{background:'#111b2b',border:'1px solid #2b3c51',borderRadius:9}}/><Area dataKey="count" stroke="#36d5d0" fill="url(#fill)" strokeWidth={2}/></AreaChart></ResponsiveContainer></div><p className="note">No detection totals are fabricated. Connect event data to populate this chart.</p></section>
              <section className="panel"><div className="panel-heading"><div><h3>Quick actions</h3><p>Continue your workflow</p></div></div><Quick icon={CloudUpload} title="Analyze video" detail="Run existing models" onClick={() => setPage('Video Analysis')}/><Quick icon={ShieldCheck} title="Review evidence" detail="Inspect candidate violations" onClick={() => { setPage('Violation Review'); void loadCases() }}/><Quick icon={Radio} title="Live monitoring" detail="Stream integration next" onClick={() => setPage('Live Monitoring')}/><div className="info-box">Model predictions are candidates. A human must verify evidence before a violation is confirmed.</div></section>
            </div>
          </>}

          {page === 'Video Analysis' && <section className="panel upload-panel"><div className="section-icon"><CloudUpload/></div><h2>Video analysis</h2><p>Upload traffic footage to the existing FastAPI inference service.</p><label className="dropzone"><input type="file" accept="video/*,.mp4,.avi,.mov,.mkv" onChange={e => setFile(e.target.files?.[0] || null)}/><CloudUpload size={32}/><strong>{file ? file.name : 'Choose a traffic video'}</strong><span>{file ? `${(file.size / 1048576).toFixed(1)} MB` : 'MP4, AVI, MOV or MKV'}</span><em>Browse files</em></label>{error && <div className="error">{error}</div>}<button className="primary" disabled={busy || !file} onClick={() => void submitVideo()}>{busy ? <RefreshCw className="spin" size={16}/> : <Video size={16}/>} {busy ? 'Submitting…' : 'Start analysis'}</button>{job && <div className="job-box"><span>JOB STATUS</span><strong>{status}</strong><small>{jobId}</small></div>}</section>}

          {page === 'Violation Review' && <section className="panel"><div className="panel-heading"><div><h3>Violation evidence review</h3><p>Candidate detections require human verification.</p></div><button className="secondary" onClick={() => void loadCases()}><RefreshCw size={15}/> Load cases</button></div>{reviewMessage && <p className="note">{reviewMessage}</p>}{cases.length === 0 ? <div className="empty"><ShieldCheck size={30}/><strong>No cases loaded</strong><p>Submit a video job first, then load its review evidence.</p></div> : <div className="case-grid">{cases.map((c, i) => <article className="case" key={c.id || c.case_id || i}><span className="tag">NEEDS VERIFICATION</span><h4>{c.violation_type || c.violation || c.label || c.class_name || 'Detection candidate'}</h4><p>Frame: {c.frame_id ?? c.frame ?? 'N/A'}</p><p>Track: {c.track_id ?? 'N/A'}</p><p>Confidence: {c.confidence != null ? `${(Number(c.confidence) * 100).toFixed(1)}%` : 'N/A'}</p></article>)}</div>}</section>}

          {page === 'Live Monitoring' && <Placeholder title="Live monitoring" text="Live camera ingest, frame-by-frame detection, vehicle tracking and real-time event integration are the next implementation phase."/>}
          {page === 'Analytics' && <Placeholder title="Traffic analytics" text="Charts will use real event data once inference telemetry is connected. No sample violation counts are shown as real results."/>}
        </div>
        <footer>TRAFFICAI • ADAPTIVE TRAFFIC INTELLIGENCE <span><i className={apiOnline ? 'green-dot' : 'amber-dot'}/>{apiOnline ? 'API reachable' : 'API not confirmed'}</span></footer>
      </main>
    </div>
  )
}

function Metric({ icon: Icon, label, value, note }: {icon: typeof Activity; label: string; value: string; note: string}) {
  return <div className="metric"><div className="metric-top">{label}<span><Icon size={18}/></span></div><strong>{value}</strong><small>{note}</small></div>
}
function Quick({ icon: Icon, title, detail, onClick }: {icon: typeof Activity; title: string; detail: string; onClick: () => void}) {
  return <button className="quick" onClick={onClick}><span className="quick-icon"><Icon size={18}/></span><span><strong>{title}</strong><small>{detail}</small></span><b>↗</b></button>
}
function Placeholder({ title, text }: {title: string; text: string}) {
  return <section className="panel placeholder"><div className="section-icon"><Radio/></div><h2>{title}</h2><p>{text}</p><div className="info-box">Planned integration surface. This screen does not claim that live processing is already implemented.</div></section>
}
