# Quick Start Guide

## 🚀 Get Started in 30 Seconds

### 1. Start the Development Server
```bash
cd E:\Minor_Project\Frontend
npm run dev
```

### 2. Open in Browser
```
http://localhost:5173
```

### 3. Login with Demo Credentials

**Option A: Developer Role**
- Email: `developer@traffic.ai`
- Password: `password`
- Click "Use Demo Account" button

**Option B: RTO Authority Role**
- Email: `authority@rto.gov.in`
- Password: `password`
- Click "Use Demo Account" button

---

## 📍 What You'll See

### After Login as Developer
You'll land on the **Developer Control Center** overview page showing:
- 4 KPI cards (Model Accuracy, Active Model, Learning Samples, API Health)
- Performance trend chart
- System health status
- Continual learning pipeline
- Recent technical events

**Left Sidebar Navigation:**
- Overview (current page)
- Models & Performance
- Continual Learning
- Data Intelligence
- System Logs
- Settings

### After Login as RTO Authority
You'll land on the **Traffic Intelligence Dashboard** showing:
- 4 KPI cards (Live Cameras, Violations Today, Pending Reviews, Fines Generated)
- Violation distribution pie chart
- Recent violations list
- Violation summary table

**Left Sidebar Navigation:**
- Traffic Overview (current page)
- Camera Surveillance
- Violations & Reviews
- Fine Intelligence
- Traffic Analytics

---

## 🔍 Pages to Explore

### Developer Dashboard (6 Pages)

**1. Overview** (`/developer/dashboard`)
- Real-time system metrics
- Performance charts
- System health monitoring
- Continual learning pipeline
- Technical event logs

**2. Models & Performance** (`/developer/models`)
- Active model (TrafficVision-v2.4)
- Detailed metrics (accuracy, precision, recall, F1, mAP)
- Per-violation-class performance breakdown
- Model version history
- Deployment status

**3. Continual Learning** (`/developer/learning`)
- Learning pipeline visualization
- Sample statistics (new, verified, hard)
- Training history chart
- Model improvement over time
- Cycle analytics

**4. Data Intelligence** (`/developer/data`)
- Three-layer data architecture
- Visual Intelligence Database
- Traffic Enforcement Database
- Continual Learning layer
- Complete data flow pipeline

**5. System Logs** (`/developer/logs`)
- Filterable event log
- Filter by service or severity
- Event statistics
- Distribution charts
- Critical event alerts

**6. System Settings** (`/developer/settings`)
- AI detection thresholds
- Performance parameters
- Service status
- API endpoints
- Configuration management

### Authority Dashboard (5 Pages)

**1. Traffic Overview** (`/authority/dashboard`)
- Live camera count
- Violations today
- Pending reviews
- Fines generated
- Violation distribution pie chart
- Recent violations list
- Summary statistics

**2. Camera Surveillance** (`/authority/cameras`)
- All cameras in grid view
- Click to select multiple cameras
- "Select All" / "Clear All" buttons
- Multi-camera surveillance display
- Camera details (name, status, violations)
- "Start Surveillance" to activate monitoring

**3. Violations & Reviews** (`/authority/violations`)
- Violation review queue
- Filter by type or status
- Click "Review" to see details
- Modal with evidence image
- AI analysis
- Human verification workflow
- Verify or Reject buttons

**4. Fine Intelligence** (`/authority/fines`)
- Fine generation statistics
- Revenue tracking
- Collection analytics
- Fine status breakdown
- Complete fine records table
- Payment tracking

**5. Traffic Analytics** (`/authority/analytics`)
- Violations trend chart
- Daily fines generated
- Daily revenue chart
- Violations by type distribution
- Verification vs rejection analysis
- Date range filtering (Today, 7 Days, 30 Days)

---

## 🎮 Interactive Features

### Multi-Camera Surveillance
1. Go to **Camera Surveillance** page
2. Click cards or checkboxes to select cameras
3. Select 1-6 cameras
4. Watch them appear in the surveillance grid below
5. Each camera shows: live indicator, FPS, violations count

### Violation Verification
1. Go to **Violations & Reviews**
2. Click "Review" on any violation
3. Modal opens with evidence and AI analysis
4. Read AI analysis confidence score
5. Click "Verify" or "Reject" to verify
6. Add officer notes
7. If verified, can generate fine

### Analytics Filtering
1. Go to **Traffic Analytics**
2. Click date range buttons (Today, 7 Days, 30 Days)
3. Charts update to show selected period
4. View trends in violations, fines, revenue

### System Monitoring
1. Go to **System Logs** (Developer)
2. Filter by Service or Severity
3. See real-time events
4. View event distribution
5. Monitor critical issues

---

## 🎨 UI/UX Tips

### Color Legend
- **Blue/Cyan**: Primary actions and information
- **Green**: Success, verified, operational
- **Amber/Orange**: Warnings, pending, in-progress
- **Red**: Errors, violations, critical
- **Purple**: Fine-related, completed actions

### Navigation Tips
- **Sidebar**: Click menu items to navigate
- **Responsive**: Sidebar collapses on mobile (<1024px)
- **Search**: Top bar has search functionality
- **Notifications**: Bell icon shows notification count
- **User Menu**: Profile appears in top right

### Common Actions
- **View Details**: Click rows or "Review" buttons
- **Select Multiple**: Click checkboxes or cards
- **Filter Data**: Use dropdown filters
- **Date Range**: Click period buttons
- **Zoom Charts**: Hover over chart for tooltips

---

## 📊 Data You'll See

### Sample Data Included
- **14 Traffic Cameras** across Bhopal
  - Bhopal Junction, MP Nagar, Habibganj, Airport Road, Ring Road, Lalghati
  - Mix of online/offline/warning statuses

- **5+ Recent Violations**
  - No Helmet, Triple Riding, Seatbelt, Signal Jumping
  - Confidence scores 92-97%
  - Various verification statuses

- **3 AI Models**
  - TrafficVision-v2.4 (Active) - 94.7% accuracy
  - TrafficVision-v2.3 (Stable) - 93.2% accuracy
  - TrafficVision-v2.2 (Archived) - 91.5% accuracy

- **Complete Training History**
  - 6 data points showing model improvement
  - Accuracy, precision, recall, F1 tracking

- **Daily Analytics**
  - 7 days of violation data
  - Fines generated per day
  - Revenue tracking

---

## ⌨️ Keyboard Shortcuts

- `Alt + D` → Developer Dashboard (if logged in as developer)
- `Alt + A` → Authority Dashboard (if logged in as authority)
- `Ctrl + K` → Global search
- `Escape` → Close modals
- `Tab` → Navigate form fields

---

## 🐛 Troubleshooting

### Dev Server Won't Start
```bash
# Kill existing process on port 5173
# Then try again
npm run dev
```

### Dependencies Issues
```bash
# Clean reinstall
rm -rf node_modules package-lock.json
npm install
```

### Stuck on Login Page
```bash
# Clear localStorage
# Open Developer Tools (F12)
# Console: localStorage.clear()
# Refresh page
```

### Charts Not Rendering
- Make sure JavaScript is enabled
- Check browser console for errors
- Try refreshing the page
- Clear browser cache

---

## 📝 Notes

- **All data is mock/demo data** - no real violations or fines
- **Authentication is mock** - any password works with correct email
- **Session persists** - data saved in localStorage
- **Ready for backend** - easy to connect to real FastAPI endpoints

---

## 🔗 Useful Links

**Inside the App:**
- Developer Overview: http://localhost:5173/developer/dashboard
- Authority Overview: http://localhost:5173/authority/dashboard
- Login: http://localhost:5173/login

**Documentation:**
- README.md - Full documentation
- IMPLEMENTATION_SUMMARY.md - Project overview

---

## ✅ What to Check First

1. **Login Page** - See the professional role selection UI
2. **Developer Overview** - Check the system health monitoring
3. **Camera Surveillance** - Try selecting multiple cameras
4. **Violations & Reviews** - Open a violation modal
5. **Traffic Analytics** - View the chart visualizations
6. **System Logs** - Filter events by severity

---

## 🎯 Demo Scenarios

### Scenario 1: Monitor System Health (Developer)
1. Login as developer
2. Go to Overview
3. Check system health cards
4. View model performance chart
5. Check continual learning pipeline

### Scenario 2: Review & Verify Violations (Authority)
1. Login as authority
2. Go to Violations & Reviews
3. Click "Review" on any violation
4. Read AI analysis
5. Click Verify or Reject
6. See it update in fine tracking

### Scenario 3: Multi-Camera Surveillance (Authority)
1. Login as authority
2. Go to Camera Surveillance
3. Select 3-4 cameras
4. Watch them appear in surveillance grid
5. See live indicators and FPS

### Scenario 4: Analyze Traffic Trends (Authority)
1. Login as authority
2. Go to Traffic Analytics
3. Switch between date ranges
4. View violation trends
5. Check revenue analytics

---

## 📞 Need Help?

- Check the **README.md** for detailed documentation
- See **IMPLEMENTATION_SUMMARY.md** for project overview
- Check browser console (F12) for error messages
- All mock data is documented in `src/data/mockData.ts`

---

## 🎉 You're Ready!

The application is fully functional and ready to explore. Start with the Overview pages to understand the layout, then dive into specific features.

**Enjoy exploring your Traffic Intelligence System! 🚀**
